import pickle

import  pandas as pd
import numpy as np
import seaborn as sns
import neattext.functions as nfx
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import MultinomialNB

from sklearn.feature_extraction.text import CountVectorizer
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score ,classification_report ,confusion_matrix
from sklearn.pipeline import Pipeline
import joblib

df =pd.read_csv(r'C:\Users\zzy\PycharmProjects\MultipleDiseasePre\multipleDisease\emotion_dataset_2.csv')

print(df['Emotion'].value_counts())
# df['Clean_Text']=df['Text'].apply(nfx.remove_userhandles)
# df['Clean_Text']=df['Clean_Text'].apply(nfx.remove_stopwords)
# df['Clean_Text']=df['Clean_Text'].apply(nfx.remove_special_characters)
df = df.dropna(axis=0)
X = df['Clean_Text']
Y = df['Emotion']

X_train,X_test,Y_train,Y_test = train_test_split(X,Y,test_size=0.2,random_state=2)
pipe_lr = Pipeline(steps=[('cv',CountVectorizer()),('lr',LogisticRegression())])
pipe_lr.fit(X_train,Y_train)
print(pipe_lr.score(X_test,Y_test))

sql = "i hate you"
print(pipe_lr.predict([sql]))

# pipe_f = open("emotion_model.pkl","wb")
# joblib.dump(pipe_lr,pipe_f)

filename = 'emotion_model.sav'
pickle.dump(pipe_lr,open(filename,'wb'))