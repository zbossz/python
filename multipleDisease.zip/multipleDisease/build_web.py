import pickle

import altair
import joblib

import requests
import streamlit as st
from cryptography.hazmat.primitives.hashes import MD5
from streamlit_option_menu import option_menu
import pandas as pd
import cv2
from PIL import Image, ImageEnhance
import numpy as np
from streamlit_webrtc import VideoTransformerBase, webrtc_streamer
import base64
from io import BytesIO
from PIL import Image
import matplotlib.pyplot as plt
import matplotlib
import seaborn as sns
from sklearn import model_selection
from sklearn.linear_model import  LogisticRegression  #逻辑回归
from sklearn.tree import DecisionTreeClassifier       #决策树
from sklearn.neighbors import  KNeighborsClassifier   #k近邻
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis  #线性判别分析
from sklearn.naive_bayes import GaussianNB            #朴素贝叶斯
from sklearn.svm import SVC                           #支持向量机
from unicodedata import decimal

matplotlib.use('Agg')

emotions_emoji_dict = {"anger": "🤬🤬", "disgust": "🤮", "fear": "😱", "happy": "🤗", "joy": "😂", "neutral": "😐",
                           "sad": "😔", "sadness": "😔", "shame": "😳", "surprise": "😮"}
diabetes_model = pickle.load(
    # open(r'C:\Users\zzy\PycharmProjects\MultipleDiseasePre\multipleDisease\diabetes_model.sav', 'rb'))
    open(r'diabetes_model.sav', 'rb'))
heart_disease_model = pickle.load(
    # open(r'C:\Users\zzy\PycharmProjects\MultipleDiseasePre\multipleDisease\heart_disease_model.sav', 'rb'))
    open(r'heart_disease_model.sav', 'rb'))
parkinsons_model = pickle.load(
    # open(r'C:\Users\zzy\PycharmProjects\MultipleDiseasePre\multipleDisease\parkinsons_model.sav', 'rb'))
    open(r'parkinsons_model.sav', 'rb'))
flagGray = 0
flagMaDi = 0
flagFlip = 0
flagContrast = 0
flagExposure = 0
flagBlurry = 0
faceDetect = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')

def plot(kind):
    st.set_option('deprecation.showPyplotGlobalUse', False)
    plt = df[selected_columns_names].plot(kind=kind)
    st.write(plt)
    st.pyplot()

def masaike(img, neighbor=9):
    h, w = img.shape[0], img.shape[1]
    img_copy = np.copy(img)
    for i in range(0, h - neighbor, neighbor):
        for j in range(0, w - neighbor, neighbor):
            color = img_copy[i][j].tolist()
            left_up = (j, i)
            right_down = (j + neighbor - 1, i + neighbor - 1)
            cv2.rectangle(img_copy, left_up, right_down, color, -1)
    return img_copy


def load_image(img):
    im = Image.open(img)
    return im


class videoTransformer(VideoTransformerBase):
    def __init__(self):
        self.i = 0

    def transform(self, frame):
        img = frame.to_ndarray(format="bgr24")
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        faces = faceDetect.detectMultiScale(gray, 1.3, 5)
        i = self.i + 1
        for (x, y, w, h) in faces:
            cv2.rectangle(img, (x, y), (x + w, y + h), (95, 207, 30), 3)
            cv2.rectangle(img, (x, y - 40), (x + w, y), (95, 207, 30), -1)
            cv2.putText(img, '人物:' + str(i), (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 0), 2)
        return img


def get_img_down_link(img, filename, text):
    buffer = BytesIO()
    img.save(buffer, format="jpeg")
    img_str = base64.b64encode(buffer.getvalue()).decode()
    href = f'<a href="data:file/jpg;base64,{img_str}" download="{filename}">{text}</a>'
    return href


def face_detect(img, sf, mn):
    i = 0
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    faces = faceDetect.detectMultiScale(gray, sf, mn)
    for (x, y, w, h) in faces:
        i = i + 1
        cv2.rectangle(img, (x, y), (x + w, y + h), (237, 30, 72), 3)
        cv2.rectangle(img, (x, y - 40), (x + w, y), (237, 30, 72), -1)
        cv2.putText(img, 'Person:' + str(i), (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)
    resi_img = cv2.resize(img, (350, 350))
    return resi_img, i, img

def showShops(type,area,what):
    shops = df.loc[(df["种类"] == type) & (df['地区'] == area)][what]
    return shops
def createAreaName(areaid):
    d = {199:"蜀山区",198:"庐阳区",197:"瑶海区",200:"包河区",5729:"经开区",5733:"政务区",
        5731:"新站区",5732:"高新区",7607:"巢湖市",2853:"肥东县",2854:"肥西县",2852:"长丰县",7205:"庐江县"}
    return d.get(areaid)
def locatebyLatLng(lat, lng, pois=0):
    '''
    https://api.map.baidu.com/reverse_geocoding/v3/?ak=您的ak&output=json&coordtype=wgs84ll&location=31.225696563611,121.49884033194
    根据经纬度查询地址
    '''
    url='https://api.map.baidu.com/reverse_geocoding/v3/?ak={0}&output=json&coordtype=wgs84ll&location={1},{2}'
    url_down = url.format('e7m1DLGUZ0o3EkNHG9KXpP6sK7F1xb7M',lat,lng)
    res = requests.get(url_down)
    result = res.json()
#     print(result)
#     print('--------------------------------------------')
    result = result['result']['business']
    return result
def predict_emotions(docx):
    results = pipe_lr.predict([docx])
    return results
def get_emotion_proba(docx):
    results = pipe_lr.predict_proba([docx])
    return results

with st.sidebar:
    st.text("本网站最好用电脑进行访问")
    activities = ["若进行其他功能，请先选此选项", "图片处理", "人脸检测", "关于"]
    choice = st.sidebar.selectbox("图像处理与分析", activities)

    activities1 = ["若进行其他功能，请先选此选项", "任意表格数据分析", "美团外卖",]
    choice1 = st.sidebar.selectbox("数据处理与分析", activities1)

    activities2 = ["若进行其他功能，请先选此选项", "情绪分析", "使用详情", ]
    choice2 = st.sidebar.selectbox("NLP自然语言处理", activities2)


    selected = option_menu('多疾病预测系统',
                           ['糖尿病预测', '心脏病预测', '帕金森预测'],
                           icons=['activity', 'heart-fill', 'person-fill'],
                           )
    # selected1 = option_menu('考研院校查询系统',
    #                        ['按照类型查询', '按照地区查询预测', '按照名称查询预测'],
    #                        icons=['activity', 'heart-fill', 'person-fill'],
    #                        default_index=0
    #                        )

    # st.table(pd.read_csv(r'C:\Users\zzy\PycharmProjects\MultipleDiseasePre\multipleDisease\diabetes.csv'))
    st.warning("进行多疾病预测的时候，图像处理与分析and数据处理与分析adnNLP三栏必须选择*【若进行其他功能，请先选此选项】*这一项")
    st.warning("进行数据处理与分析的时候，图像处理与分析一栏必须选择*【若进行其他功能，请先选此选项】*这一项")
    st.warning("进行NLP的时候，图像处理与分析与数据处理与分析两栏必须选择*【若进行其他功能，请先选此选项】*这一项")
    st.info('[©Developed by zbossz,here is my gmail:2430871434zzy@gmail.com]')
    st.info('[©本web由zbossz开发,这是我的QQ邮箱:430561907@qq.com]')
    # st.markdown(link,unsafe_allow_html=True)
    # link2 = '[©本web由zbossz开发,这是我的QQ邮箱:430561907@qq.com]()'
    # st.markdown(link2,unsafe_allow_html=True)

if choice == '图片处理':
    st.subheader("图片的处理小工具")
    image_file = st.file_uploader("上传需要检测的图片", type=['jpg', 'png', 'jpeg'])
    if image_file is not None:
        image = Image.open(image_file)
        st.text("您传入的图像:")
        st.image(image)
        col1a, col2a = st.columns(2)

        # col1, col2, col3, col4, col5 = st.columns(5)

        # with col4:
        #     if st.button('图片对比度'):
        #         flagContrast = 1

        choice = st.selectbox("请选择您需要的图片处理功能！"
                              , ('图片打码','图片转灰色', '图片翻转', '图片对比度设置', '图片曝光', '模糊图片'))
        if choice == '图片打码':
            flagMaDi = 1
            rate = st.slider("选择打码的程度:",9,100)
            image_array = np.array(image)
            MaSaiKe_image_array = masaike(image_array,rate)
            MaSaiKe_image = Image.fromarray(MaSaiKe_image_array)
        elif choice == '图片转灰色':
            flagGray = 1
            img1 = np.array(image.convert('RGB'))
            img2 = cv2.cvtColor(img1, 1)
            GrayImg = cv2.cvtColor(img2, cv2.COLOR_BGRA2GRAY)
        elif choice == '图片翻转':
            flagFlip = 1
            img_array = np.array(image.convert('RGB'))
            a, b, c = img_array.shape
            matrix = img_array[a:0:-1, b:0:-1]
            img_flip = Image.fromarray(matrix)
        elif choice == '图片对比度设置':
            flagContrast = 1
            rate = st.slider("对比度", 0.0, 10.0)
            enhancer = ImageEnhance.Contrast(image)
            img_out = enhancer.enhance(rate)
        elif choice == '图片曝光':
            flagContrast = 1
            rate = st.slider("曝光度", 0.0, 30.0)
            enhancer = ImageEnhance.Brightness(image)
            img_out = enhancer.enhance(rate)
        elif choice == '模糊图片':
            flagBlurry = 1
            rate = st.slider("模糊度", 0.0, 10.0)
            img1 = np.array(image.convert('RGB'))
            img2 = cv2.cvtColor(img1, 1)
            BlurryImg = cv2.GaussianBlur(img2, (11, 11), rate)

        if flagGray == 1:
            st.write("转灰后的图像:")
            st.image(GrayImg)
            flagGray = 0
            st.markdown(get_img_down_link(GrayImg, image_file.name, '点击这里下载转换后的图片'), unsafe_allow_html=True)
        elif flagMaDi == 1:
            st.write("打码后的图像:")
            st.image(MaSaiKe_image)
            st.markdown(get_img_down_link(MaSaiKe_image, image_file.name, '点击这里下载转换后的图片'), unsafe_allow_html=True)
            flagMaDi = 0
        elif flagFlip == 1:
            st.write("翻转后的图像:")
            st.image(img_flip)
            st.markdown(get_img_down_link(img_flip, image_file.name, '点击这里下载转换后的图片'), unsafe_allow_html=True)
            flagFlip = 0
        elif flagContrast == 1:
            st.write("设置对比度后的图像:")
            st.image(img_out)
            st.markdown(get_img_down_link(img_out, image_file.name, '点击这里下载转换后的图片'), unsafe_allow_html=True)
            flagContrast = 0
        elif flagExposure == 1:
            st.write("设置曝光度后的图像:")
            st.image(img_out)
            st.markdown(get_img_down_link(img_out, image_file.name, '点击这里下载转换后的图片'), unsafe_allow_html=True)
            flagExposure = 0
        elif flagBlurry == 1:
            st.write("设置模糊度后的图像:")
            st.image(BlurryImg)
            st.markdown(get_img_down_link(BlurryImg, image_file.name, '点击这里下载转换后的图片'), unsafe_allow_html=True)
            flagBlurry = 0



elif choice == '人脸检测':
    st.title("人脸检测基于opencv")
    activities = ["图片检测", ]
    st.markdown("### 请选择图片检测或者摄像头检测")
    choice = st.selectbox("请选择：", activities)
    if (choice == '图片检测'):
        st.markdown(
            '''<h4 style='text-aligh: left;color : red;'>* 面部检测基于opencv</h4>''',
            unsafe_allow_html=True
        )
        img_file = st.file_uploader("请选择一张图片", type=['jpg', 'jpeg', 'jfif', 'png'])
        if img_file is not None:
            img = np.array(Image.open(img_file))
            img1 = cv2.resize(img, (350, 350))
            col1, col2 = st.columns(2)
            col1.image(img1)
            st.markdown(
                '''<h4 style= 'text-align:left;color: blue;'>*调控滑杆去获取最佳的检测结果''',
                unsafe_allow_html=True
            )
            scale_factor = st.slider("设置比例因子值", min_value=1.1, max_value=1.9, step=0.1, value=1.3)
            min_Neighber = st.slider("设置缩放最小间隔人物", min_value=1, max_value=9, step=1, value=5)
            fd, count, orignal_img = face_detect(img, scale_factor, min_Neighber)
            col2.image(fd)
            if count == 0:
                st.error("抱歉，好像没找到人，可以尝试调整滑杆。或者此图无人")
            else:
                st.success("一共找到了:" + str(count) + "个人")
                result = Image.fromarray(orignal_img)
                st.markdown(get_img_down_link(result, img_file.name, '点击这里下载图片'), unsafe_allow_html=True)
    # if choice == "摄像头检测":
    #     st.markdown(
    #         '''<h4 style='text-align:left;color:red;'> 这个功能暂不可用</h4>''',
    #         unsafe_allow_html=True
    #     )
    #     webrtc_streamer(key="example", video_transformer_factory=videoTransformer)

elif choice == '关于':
    st.subheader("关于")
    st.text("这是我为人工智能概论课程做的小网站，作为结课的作业。\n作者：zbossz（zbossz是网络创作用名）。"
            "\n我的邮箱就在左边的菜单栏里。")
if choice =="若进行其他功能，请先选此选项" and choice1 =="任意表格数据分析":
    st.title("任意表格数据图像分析")
    activities2 = ["探索性数据分析","图像分析","建立模型"]
    choice3 = st.selectbox("选择操作",activities2)
    if choice3 == "探索性数据分析":
        data = st.file_uploader("上传数据集",type=["csv","txt"])
        if data is not None:
            df = pd.read_csv(data)
            st.dataframe(df.head(10))
            col1,col2 = st.columns(2)
            with col1:
                if st.checkbox("展示数据的规格"):
                    st.write(df.shape)
                    label = st.text_input("请输入您的数据的结果列")
                    if label != "":
                        st.write(df.iloc[:,int(label)].value_counts())
            with col2:
                if st.checkbox("展示数据的列名"):
                    st.write(df.columns.to_list())
            if st.checkbox("显示数据概要"):
                st.write(df.describe())

            if st.checkbox("显示该数据有没有重复数据"):
                st.dataframe(df[df.duplicated()])
            if st.checkbox("选择要展示的列的数据"):
                selected_columns = st.multiselect("选择要展示的列",df.columns.to_list())
                new_df = df[selected_columns]
                st.dataframe(new_df)
    elif choice3 == "图像分析":
        data = st.file_uploader("上传数据集", type=["csv", "txt"])
        if data is not None:
            df = pd.read_csv(data)
            st.dataframe(df.head(10))
            if st.checkbox("相关性分析"):
                fig, ax = plt.subplots()
                st.write(sns.heatmap(df.corr(),annot=True))
                st.pyplot(fig)
            if st.checkbox("饼状图分析"):
                fig1,ax = plt.subplots()
                all_columns = df.columns.to_list()
                columns_to_plot = st.selectbox("选一列作为饼状图分析数据",all_columns)
                pie_plot = df[columns_to_plot].value_counts().plot.pie(autopct = "%1.1f%%")
                st.write(pie_plot)
                st.pyplot(fig1)
            all_columns_names = df.columns.tolist()
            type_of_plot = st.selectbox("选择绘图的种类:",["区域图","条状图","线型图","直方图","盒装图","kde"])
            selected_columns_names = st.multiselect("选择要画的数据列",all_columns_names)
            if st.button("生成图像"):
                if type_of_plot =="区域图":
                    data = df[selected_columns_names]
                    st.area_chart(data)
                elif type_of_plot =="条状图":
                    data = df[selected_columns_names]
                    st.bar_chart(data)
                elif type_of_plot =="线型图":
                    data = df[selected_columns_names]
                    st.line_chart(data)
                elif type_of_plot == "直方图":
                    plot("hist")
                elif type_of_plot =="盒装图":
                    plot("box")
                elif type_of_plot =="kde":
                    plot("kde")
    elif choice3 == "建立模型":
        data = st.file_uploader("上传数据集", type=["csv", "txt"])
        if data is not None:
            df = pd.read_csv(data)
            st.dataframe(df.head(10))
            all_columns = df.columns.to_list()
            label =st.text_input("请输入您得数据集得标签列是多少(数字)，最后一列可用-1表示，以此类推，默认是最后一列")
            if label !="":
                label1 = int(label)
                X = df.iloc[:,0:label1]
                Y = df.iloc[:,label1]
                seed = 7
                models = []
                models.append(("逻辑回归模型",LogisticRegression()))
                models.append(("线性判别分析模型",LinearDiscriminantAnalysis()))
                models.append(("k近邻模型",KNeighborsClassifier()))
                models.append(("决策树模型",DecisionTreeClassifier()))
                models.append(("朴素贝叶斯模型",GaussianNB()))
                models.append(("支持向量机模型",SVC()))

                model_names=[]
                model_mean = []
                model_std =[]
                all_models =[]
                score = 'accuracy'
                for name,model in models:
                    kfold = model_selection.KFold(n_splits=10,random_state=seed,shuffle=True)
                    cv_results = model_selection.cross_val_score(model,X,Y,cv=kfold,scoring=score)
                    model_names.append(name)
                    model_mean.append(cv_results.mean())
                    model_std.append(cv_results.std())
                    accuracy_results = {"模型名称":name,"模型精度":cv_results.mean(),"模型标准差":cv_results.std()}
                    all_models.append(accuracy_results)
                if st.checkbox("结果表格"):
                    st.dataframe(pd.DataFrame(zip(model_names,model_mean,model_std),columns=["模型名称              ","模型精度         ","模型标准差        "]))

                if st.checkbox("结果json"):
                    st.json(all_models)


elif choice =="若进行其他功能，请先选此选项" and choice1 =="美团外卖":
    st.title("美团外卖爬虫数据使用")
    col1,col2= st.columns(2)
    with col1:
        # df = pd.read_csv(r'C:\Users\zzy\PycharmProjects\MultipleDiseasePre\multipleDisease\HfData.csv')
        df = pd.read_csv(r'HfData.csv')
        menu2 = df['种类'].unique().tolist()
        # menu2 = ["火锅","烤肉","日韩料理","甜点","奶茶","西餐","关于"]
        choice2 = st.selectbox("请选择您需要筛选的美食类别",menu2)
    with col2:
        menu3 = ["蜀山区", "庐阳区", "瑶海区", "包河区", "经开区", "政务区", "新站区","高新区","巢湖市","肥东县","肥西县","长丰县","庐江县"]
        choice3 = st.selectbox("请选择您需要筛选的区域", menu3)

    evaluate_columns = ["店铺名称","店内最低价","人均消费","店铺评分","评论人数","套餐/代金券(筛选)","地区"]
    selected_choices = st.multiselect("选择您想参考的条件",evaluate_columns)
    if selected_choices is not None:
        st.dataframe(showShops(choice2,choice3,selected_choices))
    text = st.text_input("请输入您想查找的特定店铺名称")
    if text != "":
        evaluate_columns1 = ["店铺名称", "店内最低价", "人均消费", "店铺评分", "评论人数", "套餐/代金券(筛选)", "地区","纬度","经度"]
        selected_choices1 = st.multiselect("选择您想参考该商家的条件", evaluate_columns1)
        if selected_choices is not None:
            st.dataframe(df.loc[(df['店铺名称']==text)][selected_choices1])
            lat =  df.loc[(df['店铺名称']==text)]["纬度"].tolist()
            lng =  df.loc[(df['店铺名称']==text)]["经度"].tolist()
            st.success("经过百度地图的经纬度定位，该商圈位于 ： "+locatebyLatLng(lat[0],lng[0]))




    if choice2=="关于":
        st.text("此内容只是一个爬虫的初级应用而已。\n只是为了使用爬虫数据。\n让它有点用罢了。\n类似可以做很多的推荐系统。")

# elif choice == "若进行其他功能，请先选此选项" and choice1 =="":


elif choice =="若进行其他功能，请先选此选项" and choice1 =="若进行其他功能，请先选此选项":
    # pipe_lr = pickle.load(open(r"C:\Users\zzy\PycharmProjects\MultipleDiseasePre\multipleDisease\emotion_model.sav","rb"))
    pipe_lr = pickle.load(open(r"emotion_model.sav","rb"))


    if choice2 =="情绪分析":
        st.title("情绪分类")
        with st.form(key='emotion_classfier'):
            raw_text = st.text_area("请在这里输入")
            submit_text = st.form_submit_button(label="提交")
        if submit_text:
            prediction = predict_emotions(raw_text)

            probability = get_emotion_proba(raw_text)
            col1,col2 = st.columns(2)
            with col1:
                st.success("原始文本：")
                st.write(raw_text)
                st.success("预测：")
                emoji_icon = emotions_emoji_dict[prediction[0]]
                st.write("{}:{}".format(prediction[0],emoji_icon))
                st.write("可信度:{}".format(np.max(probability)))
            with col2:
                st.success("预测准确度:")
                # st.write(probability)
                proba_df = pd.DataFrame(probability,columns=pipe_lr.classes_)
                # st.write(proba_df.T)
                proba_df_clean = proba_df.T.reset_index()
                proba_df_clean.columns = ["emotions","probability"]
                fig = altair.Chart(proba_df_clean).mark_bar().encode(x="emotions",y="probability",color='emotions' )
                st.altair_chart(fig,use_container_width=True)
# """
# 这里开始多疾病预测系统
# """
elif choice =="若进行其他功能，请先选此选项" and choice1 =="若进行其他功能，请先选此选项" and choice2=="若进行其他功能，请先选此选项":
    if (selected == '糖尿病预测'):
        # st.dataframe(pd.read_csv(r'C:\Users\zzy\PycharmProjects\MultipleDiseasePre\multipleDisease\diabetes.csv'))
        st.dataframe(pd.read_csv(r'diabetes.csv'))
        st.title('糖 尿 病 预 测 系 统 基 于 机 器 学 习')
        col1, col2, col3 = st.columns(3)

        with col1:
            Pregnancies = st.text_input('怀孕次数')
        with col2:
            Glucose = st.text_input('血糖水平')
        with col3:
            BloodPressure = st.text_input('血压水平')
        with col1:
            SkinThickness = st.text_input('皮脂厚度')
        with col2:
            Insulin = st.text_input('胰岛素水平')
        with col3:
            BMI = st.text_input('体重指数')
        with col1:
            DiabetesPredigreeFunction = st.text_input('糖尿病前期功能')
        with col2:
            Age = st.text_input('年龄')
        diab_dignosis = ''
        st.warning("必须键入所有数据,才能点预测,数据可使用上述表格的数据！")
        if (st.button('预测')):
            prediction = diabetes_model.predict([[Pregnancies, Glucose, BloodPressure, SkinThickness, Insulin,
                                                  BMI, DiabetesPredigreeFunction, Age]])
            if (prediction[0] == 1):
                diab_dignosis = '数据人员为糖尿病患者'
            else:
                diab_dignosis = '数据人员非糖尿病患者'
                st.balloons()
        st.success(diab_dignosis)

    elif (selected == '心脏病预测'):
        # st.dataframe(pd.read_csv(r'C:\Users\zzy\PycharmProjects\MultipleDiseasePre\multipleDisease\heart.csv'))
        st.dataframe(pd.read_csv(r'heart.csv'))
        st.title('心 脏 病 预 测 系 统 基 于 机 器 学 习')

        col1, col2, col3 = st.columns(3)

        with col1:
            age = st.text_input('年龄')

        with col2:
            sex = st.text_input('性别')

        with col3:
            cp = st.text_input('胸痛类型')

        with col1:
            trestbps = st.text_input('静息血压')

        with col2:
            chol = st.text_input('血清胆固醇（mg/dl）')

        with col3:
            fbs = st.text_input('空腹血糖>120毫克/分升')

        with col1:
            restecg = st.text_input('静息心电图结果')

        with col2:
            thalach = st.text_input('达到最大心率')

        with col3:
            exang = st.text_input('运动性心绞痛')

        with col1:
            oldpeak = st.text_input('运动诱发ST段压低').strip()

        with col2:
            slope = st.text_input('峰值运动ST段斜率')

        with col3:
            ca = st.text_input('透视着色的主要血管')

        with col1:
            thal = st.text_input('thal：0=正常；1=固定缺陷；2=可逆缺陷')

        heart_diagnosis = ''

        st.warning("必须键入所有数据,才能点预测,数据可使用上述表格的数据！")
        # st.error("心脏病预测暂时有问题！！不可用！！")
        if st.button('预测'):
            array1 = [age, sex, cp, trestbps, chol, fbs, restecg, thalach, exang, oldpeak, slope, ca, thal]
            array2 = np.array(array1, dtype=float)
            heart_prediction = heart_disease_model.predict([array2])
            if (heart_prediction[0] == 1):
                heart_diagnosis = '数据人员患有心脏病'
            else:
                heart_diagnosis = '数据人员没有心脏病'
                st.balloons()

        st.success(heart_diagnosis)

    elif (selected == '帕金森预测'):
        # st.dataframe(pd.read_csv(r'C:\Users\zzy\PycharmProjects\MultipleDiseasePre\multipleDisease\parkinsons.csv'))
        st.dataframe(pd.read_csv(r'parkinsons.csv'))
        st.title('帕 金 森 预 测 系 统 基 于 机 器 学 习')
        col1, col2, col3, col4, col5 = st.columns(5)

        with col1:
            fo = st.text_input('MDVP:Fo(Hz)平均人声基频')

        with col2:
            fhi = st.text_input('MDVP:Fhi(Hz)最大人声基频')

        with col3:
            flo = st.text_input('MDVP:Flo(Hz)最小人声基频')

        with col4:
            Jitter_percent = st.text_input('MDVP:Jitter(%)基频变化的测量方法')

        with col5:
            Jitter_Abs = st.text_input('MDVP:Jitter(Abs)基频变化的测量方法')

        with col1:
            RAP = st.text_input('MDVP:RAP基频变化的测量方法')

        with col2:
            PPQ = st.text_input('MDVP:PPQ基频变化的测量方法')

        with col3:
            DDP = st.text_input('Jitter:DDP基频变化的测量方法')

        with col4:
            Shimmer = st.text_input('MDVP:Shimmer\n\n')

        with col5:
            Shimmer_dB = st.text_input('MDVP:Shimmer(dB)幅度变化的测量')

        with col1:
            APQ3 = st.text_input('Shimmer:APQ3幅度变化的测量')

        with col2:
            APQ5 = st.text_input('Shimmer:APQ5幅度变化的测量')

        with col3:
            APQ = st.text_input('MDVP:APQ幅度变化的测量')

        with col4:
            DDA = st.text_input('Shimmer:DDA幅度变化的测量')

        with col5:
            NHR = st.text_input('NHR语音状态中噪声与音调分量比的测量')

        with col1:
            HNR = st.text_input('HNR语音状态中噪声与音调分量比的测量')

        with col2:
            RPDE = st.text_input('RPDE非线性动态复杂性度量')

        with col3:
            DFA = st.text_input('DFA信号分形缩放指数')

        with col4:
            spread1 = st.text_input('spread1基本频率变化的非线性测量')

        with col5:
            spread2 = st.text_input('spread2基本频率变化的非线性测量')

        with col1:
            D2 = st.text_input('D2非线性动态复杂性度量')

        with col2:
            PPE = st.text_input('PPE基本频率变化的非线性测量')

        parkinsons_diagnosis = ''
        st.warning("必须键入所有数据,才能点预测,数据可使用上述表格的数据！")

        if st.button("预测"):
            parkinsons_prediction = parkinsons_model.predict([[fo, fhi, flo, Jitter_percent, Jitter_Abs, RAP, PPQ, DDP,
                                                               Shimmer, Shimmer_dB, APQ3, APQ5, APQ, DDA, NHR, HNR,
                                                               RPDE,
                                                               DFA, spread1, spread2, D2, PPE]])

            if (parkinsons_prediction[0] == 1):
                parkinsons_diagnosis = "数据人员患有帕金森"
            else:
                parkinsons_diagnosis = "数据人员没有帕金森"
                st.balloons()

        st.success(parkinsons_diagnosis)
# if selected1 =='按照类型查询':
#     st.write('你点了按照类型查询')
