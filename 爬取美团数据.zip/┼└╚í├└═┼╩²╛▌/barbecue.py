"""
https://apimobile.meituan.com/group/v4/poi/pcsearch/56?
uuid=5b677c3c0376457e9763.1653574846.1.0.0
&userid=2953714672
&limit=32
&offset=64
&cateId=-1
&q=烤肉
&token=rFAJ3nsWtn3bBj-IGBeAno_ijpwAAAAA-REAALRNz90azWWU_HOPiCK0t4GoB9xwYJu6Am7WDGa3YahZx19U5kRow4HfS87Z0BFkbw

第一面的offset是0，page2的offset是32，page3的offset是64，page4的offset是96

https://apimobile.meituan.com/group/v4/poi/pcsearch/56?
uuid=5b677c3c0376457e9763.1653574846.1.0.0
&userid=2953714672
&limit=32
&offset=0
&cateId=-1
&q=烤肉
&token=rFAJ3nsWtn3bBj-IGBeAno_ijpwAAAAA-REAALRNz90azWWU_HOPiCK0t4GoB9xwYJu6Am7WDGa3YahZx19U5kRow4HfS87Z0BFkbw
&areaId=199
"""
import json
import random
import time

import pymysql
import requests

"""
Accept: */*
Accept-Encoding: gzip, deflate, br
Accept-Language: zh-CN,zh;q=0.9,zh-TW;q=0.8,ja;q=0.7,en;q=0.6
Connection: keep-alive
==================================================
Cookie: 
_lxsdk_cuid=1806f954277c8-05a27a17808f5c-6b3e555b-144000-1806f954277c8; 
iuuid=83FBD520F132E2A1F39F1158AB42DF12753F99D42A69E1A6AF6EC865C0789C0F;
 cityname=%E5%90%88%E8%82%A5; 
 _lxsdk=83FBD520F132E2A1F39F1158AB42DF12753F99D42A69E1A6AF6EC865C0789C0F; 
 webp=1; 
 latlng=31.90799,117.284414,1653528384374; 
 __utmz=74597006.1653528384.1.1.utmcsr=baidu|utmccn=(organic)|utmcmd=organic; 
 __utma=74597006.1922642554.1653528384.1653528384.1653528384.1; 
 i_extend=C_b1Gimthomepagecategory1394H__a; 
 wm_order_channel=mtib; 
 utm_source=60030; 
 request_source=openh5; 
 mtcdn=K; 
 uuid=5b677c3c0376457e9763.1653574846.1.0.0; ci=56; 
 rvct=56%2C1%2C80; 
 userTicket=mwyBNwoqajWulxbtgreTEocAEJRjiXhliFqkMOgi; 
 _yoda_verify_resp=j8HZdT2D5ADQXnosW%2ByjA9lp4EBBdSvq68fbsAvKnOqnpQ4vpEIWiycoEuCPjNsEyDxVEVbymqNcyENPbfsjlhympRCgvnYBJqP5MrgjcNU4gTLrhicMjlWw48TR0BexzuBbkhVD5QdB7gknYEU0umMxMgTXHtbmlru%2BXspzpFXcYILarLmO0upUK913I78wqodkpiYMWWFsXi1KUYI2eIU3pAx%2B54llTpUemNLEESW2znMIDUerHq0q9sGBy%2B%2Fb10Wazm%2FqEh%2BuMtaEkvcd8CYRnOPE06wuMFjeAbq855z0AwPgEpRpDSQmkIkqAa%2FjA%2BxSzOYIrlVQdrURBmaPQmgjQtzqWBWyqzqzn6b1J3xNVdyuLJucjwMbe71xP%2B%2Fi; 
 _yoda_verify_rid=153b1493e641705d;
  u=2953714672; 
  n=XwJ584136182; 
  lt=rFAJ3nsWtn3bBj-IGBeAno_ijpwAAAAA-REAALRNz90azWWU_HOPiCK0t4GoB9xwYJu6Am7WDGa3YahZx19U5kRow4HfS87Z0BFkbw;
   mt_c_token=rFAJ3nsWtn3bBj-IGBeAno_ijpwAAAAA-REAALRNz90azWWU_HOPiCK0t4GoB9xwYJu6Am7WDGa3YahZx19U5kRow4HfS87Z0BFkbw; 
   token=rFAJ3nsWtn3bBj-IGBeAno_ijpwAAAAA-REAALRNz90azWWU_HOPiCK0t4GoB9xwYJu6Am7WDGa3YahZx19U5kRow4HfS87Z0BFkbw; 
   token2=rFAJ3nsWtn3bBj-IGBeAno_ijpwAAAAA-REAALRNz90azWWU_HOPiCK0t4GoB9xwYJu6Am7WDGa3YahZx19U5kRow4HfS87Z0BFkbw; 
   unc=XwJ584136182; 
   _lx_utm=utm_source%3DBaidu%26utm_medium%3Dorganic; 
   firstTime=1653578143028; 
   _lxsdk_s=18100bdb21e-be3-82f-dc3%7C%7C553
   ==========================================================
Host: apimobile.meituan.com
Origin: https://hf.meituan.com
Referer: https://hf.meituan.com/
sec-ch-ua: " Not A;Brand";v="99", "Chromium";v="101", "Google Chrome";v="101"
sec-ch-ua-mobile: ?0
sec-ch-ua-platform: "Windows"
Sec-Fetch-Dest: empty
Sec-Fetch-Mode: cors
Sec-Fetch-Site: same-site
User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.0.0 Safari/537.36
"""
sql_create_table = 'create table if not exists barbecue(' \
                   'Id int not null,' \
                   'Title varchar(50),' \
                   'Address varchar(100),' \
                   'LowestPrice float,' \
                   'AvgPrice float ,' \
                   'AvgScore float ,' \
                   'Comments int,' \
                   'AreaId int,' \
                   'AreaName varchar(50),' \
                   'Template varchar(50),' \
                   'ImgUrl varchar(300),' \
                   'BackCateName varchar(50),' \
                   'Longitude float ,' \
                   'Latitude float ,' \
                   'Phone varchar(15),' \
                   'Deals varchar(3000)' \
                   ');'
connection = pymysql.Connection(host='localhost',user='root',password='zbosszsql',db='meituanbarbecue')
cur=connection.cursor()
cur.execute(sql_create_table)



url = 'https://apimobile.meituan.com/group/v4/poi/pcsearch/56?uuid={0}&userid={1}&limit=32&offset={2}' \
      '&cateId=-1&q=%E7%83%A4%E8%82%89&token={3}&areaId={4}'
header = {
    'Accept':'*/*',
    'Accept-Encoding':'gzip, deflate, br',
    'Accept-Language':'zh-CN,zh;q=0.9,zh-TW;q=0.8,ja;q=0.7,en;q=0.6',
    'Connection':'keep-alive',
    'Host':'apimobile.meituan.com',
    'Origin':'https//hf.meituan.com',
    'Referer':'https//hf.meituan.com/',
    'sec-ch-ua':'" Not A;Brand";v="99", "Chromium";v="101", "Google Chrome";v="101"',
    'sec-ch-ua-mobile':'?0',
    'sec-ch-ua-platform':'"Windows"',
    'Sec-Fetch-Dest':'empty',
    'Sec-Fetch-Mode':'cors',
    'Sec-Fetch-Site':'same-site',
    'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.0.0 Safari/537.36'
}

cookie ={
'_lxsdk_cuid':'1806f954277c8-05a27a17808f5c-6b3e555b-144000-1806f954277c8',
'iuuid':'83FBD520F132E2A1F39F1158AB42DF12753F99D42A69E1A6AF6EC865C0789C0F',
'_lxsdk':'83FBD520F132E2A1F39F1158AB42DF12753F99D42A69E1A6AF6EC865C0789C0F',
# 'webp':'1',
'latlng':'31.90799,117.284414,1653528384374',
'__utmz':'74597006.1653528384.1.1.utmcsr=baidu|utmccn=(organic)|utmcmd=organic',
'__utma':'74597006.1922642554.1653528384.1653528384.1653528384.1',
'i_extend':'C_b1Gimthomepagecategory1394H__a',
'wm_order_channel':'mtib',
'utm_source':'60030',
'request_source':'openh5',
'mtcdn':'K',
'uuid':'5b677c3c0376457e9763.1653574846.1.0.0',
'ci':'56',
'rvct':'56%2C1%2C80',
'userTicket':'mwyBNwoqajWulxbtgreTEocAEJRjiXhliFqkMOgi',
'_yoda_verify_resp':'j8HZdT2D5ADQXnosW%2ByjA9lp4EBBdSvq68fbsAvKnOqnpQ4vpEIWiycoEuCPjNsEyDxVEVbymqNcyENPbfsjlhympRCgvnYBJqP5MrgjcNU4gTLrhicMjlWw48TR0BexzuBbkhVD5QdB7gknYEU0umMxMgTXHtbmlru%2BXspzpFXcYILarLmO0upUK913I78wqodkpiYMWWFsXi1KUYI2eIU3pAx%2B54llTpUemNLEESW2znMIDUerHq0q9sGBy%2B%2Fb10Wazm%2FqEh%2BuMtaEkvcd8CYRnOPE06wuMFjeAbq855z0AwPgEpRpDSQmkIkqAa%2FjA%2BxSzOYIrlVQdrURBmaPQmgjQtzqWBWyqzqzn6b1J3xNVdyuLJucjwMbe71xP%2B%2Fi',
'_yoda_verify_rid':'153b1493e641705d',
'u':'2953714672',
'n':'XwJ584136182',
'lt':'rFAJ3nsWtn3bBj-IGBeAno_ijpwAAAAA-REAALRNz90azWWU_HOPiCK0t4GoB9xwYJu6Am7WDGa3YahZx19U5kRow4HfS87Z0BFkbw',
'token':'rFAJ3nsWtn3bBj-IGBeAno_ijpwAAAAA-REAALRNz90azWWU_HOPiCK0t4GoB9xwYJu6Am7WDGa3YahZx19U5kRow4HfS87Z0BFkbw',
'unc':'XwJ584136182',
'_lx_utm':'utm_source%3DBaidu%26utm_medium%3Dorganic',
'firstTime':'1653578143028',
'_lxsdk_s':'18100bdb21e-be3-82f-dc3%7C%7C553',
}
token = cookie.get('token')
uuid = cookie.get('uuid')
userid = cookie.get('u')
# areaId = [199,198,197,200,5729,5733,5731,5732,7607,2853,2854,2852,7205]
areaId = [2854,2852,7205]
for id in areaId:
    flag = 0 #flag==0的时候，数据还没有爬完
    for x in range(0,1024,32):
        if flag==1:
            break
        print('正在提取areaId为%d的'%id,'第%d页'%int((x+32)/32))
        url_down = url.format(uuid,userid,x,token,id)
        print(url_down)
        response = requests.get(url_down,headers=header,cookies=cookie)
        if response.status_code ==200:
            data = json.loads(response.text)['data']['searchResult']
            if len(data) <32:
                print('areaId为%d的数据一共有%d条，即将爬取下一个地区的数据。'%(id,x))
                flag = 1;

            for record in data:
                storeid = record.get('id')
                template = record.get('template')
                imgURL = record.get('imageUrl')
                title = record.get('title')
                address = record.get('address')
                lowestprice = record.get('lowestprice')
                comments = record.get('comments')
                areaid = id
                areaname = record.get('areaname')
                backCateName = record.get('backCateName')
                avgprice = record.get('avgprice')
                avgscore = record.get('avgscore')
                longitude = record.get('longitude')
                latitude = record.get('latitude')
                deals = str(record.get('deals'))
                phone = record.get('phone')

                info = (storeid, title, address, lowestprice, avgprice, avgscore, comments,
                        areaid, areaname, template, imgURL, backCateName, longitude,
                        latitude, phone, deals)

                sql_insert = 'insert into barbecue values ("{0}","{1}","{2}","{3}","{4}","{5}","{6}","{7}","{8}","{9}","{10}","{11}","{12}","{13}","{14}","{15}");'.format(info[0],str(info[1]),'无' if info[2]=="" else str(info[2]),info[3],info[4],info[5],info[6],info[7],str(info[8]),str(info[9]),str(info[10]),str(info[11]),info[12],info[13],'无' if info[14]=="" else str(info[14]),str(info[-1]))
                print(sql_insert)
                try:
                    cur.execute(sql_insert)
                    connection.commit()
                except Exception as e:
                    print(e)
                    connection.rollback()
        else:
            print(response.status_code)
        time.sleep(random.randint(12,24))

cur.close()
connection.close()