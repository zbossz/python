import pymysql
import pandas as pd
connection = pymysql.connect(host='localhost',user='root',password='zbosszsql',database='meituanbarbecue')
cur = connection.cursor()
#这是烤肉的数据
sql = 'select * from barbecue'
cur.execute(sql)
df_barbecue = cur.fetchall()
df_barbecue = [list(data) for data in df_barbecue]
df_barbecue = pd.DataFrame(data=df_barbecue,columns=['店铺编号', '店铺名称', '店铺地址', '店内最低价', '人均消费', '店铺评分', '评论人数', '地区id', '商圈', 'template', '图片链接', '烤肉种类', '经度', '纬度', '电话', '套餐/代金券'])
df_barbecue['种类'] ="烤肉"
print(df_barbecue.shape)
#这是日韩料理的数据
sql1 = 'select * from cuisine'
cur.execute(sql1)
df_cuisine = cur.fetchall()
df_cuisine = [list(data) for data in df_cuisine]
df_cuisine = pd.DataFrame(data=df_cuisine,columns=['店铺编号', '店铺名称', '店铺地址', '店内最低价', '人均消费', '店铺评分', '评论人数', '地区id', '商圈', 'template', '图片链接', '烤肉种类', '经度', '纬度', '电话', '套餐/代金券'])
df_cuisine['种类'] ="日韩料理"
print(df_cuisine.shape)
#这是甜点的数据
sql2 = 'select * from dessert'
cur.execute(sql2)
df_dessert = cur.fetchall()
df_dessert = [list(data) for data in df_dessert]
df_dessert = pd.DataFrame(data=df_dessert,columns=['店铺编号', '店铺名称', '店铺地址', '店内最低价', '人均消费', '店铺评分', '评论人数', '地区id', '商圈', 'template', '图片链接', '烤肉种类', '经度', '纬度', '电话', '套餐/代金券'])
df_dessert['种类'] ="甜点"

print(df_dessert.shape)
#这是火锅的数据
sql3 = 'select * from hotpot'
cur.execute(sql3)
df_hotpot = cur.fetchall()
df_hotpot = [list(data) for data in df_hotpot]
df_hotpot = pd.DataFrame(data=df_hotpot,columns=['店铺编号', '店铺名称', '店铺地址', '店内最低价', '人均消费', '店铺评分', '评论人数', '地区id', '商圈', 'template', '图片链接', '烤肉种类', '经度', '纬度', '电话', '套餐/代金券'])
df_hotpot['种类'] ="火锅"
print(df_hotpot.shape)
#这是奶茶的数据
sql4 = 'select * from milktea'
cur.execute(sql4)
df_milktea = cur.fetchall()
df_milktea = [list(data) for data in df_milktea]
df_milktea = pd.DataFrame(data=df_milktea,columns=['店铺编号', '店铺名称', '店铺地址', '店内最低价', '人均消费', '店铺评分', '评论人数', '地区id', '商圈', 'template', '图片链接', '烤肉种类', '经度', '纬度', '电话', '套餐/代金券'])
df_milktea['种类'] ="奶茶"
print(df_milktea.shape)
#这是西餐的数据
sql5 = 'select * from westernfood'
cur.execute(sql5)
df_westernfood = cur.fetchall()
df_westernfood = [list(data) for data in df_westernfood]
df_westernfood = pd.DataFrame(data=df_westernfood,columns=['店铺编号', '店铺名称', '店铺地址', '店内最低价', '人均消费', '店铺评分', '评论人数', '地区id', '商圈', 'template', '图片链接', '烤肉种类', '经度', '纬度', '电话', '套餐/代金券'])
df_westernfood['种类'] ="西餐"
print(df_westernfood.shape)

#合并所有数据到一张表上
df_all = pd.concat([df_barbecue,df_cuisine,df_dessert,df_hotpot,df_milktea,df_westernfood],ignore_index=True)
print(df_all.shape)
print(df_all.info())
df_all = df_all[['店铺编号', '图片链接','店铺名称', '店内最低价', '人均消费', '店铺评分', '评论人数', '地区id', '商圈', '烤肉种类', '经度', '纬度', '套餐/代金券','种类']]
print(df_all.shape)
print(df_all.info())
print("==================================================================================")
dupli_data = df_all[df_all.duplicated()]
print(df_all[(df_all['店铺编号']==1472414664)])
print("==================================================================================")
df_all_drop_dup = df_all.drop_duplicates()
print(df_all_drop_dup.shape,df_all.shape)
print(df_all_drop_dup.info())
# df_all_drop_dup['商圈'] = df_all_drop_dup['商圈'].astype(str)
# df_all_drop_dup['店铺名称'] = df_all_drop_dup['店铺名称'].astype(str)
# df_all_drop_dup['图片链接'] = df_all_drop_dup['图片链接'].astype(str)
# print(df_all_drop_dup.info())
df_all_drop_dup.to_csv('HeFeiallData.csv',index=False,encoding='utf_8_sig')
